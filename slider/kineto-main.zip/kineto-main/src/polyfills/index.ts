export { polyfill as polyfillRequestAnimationFrame } from './requestAnimationFrame';
