import container from './container';
import frame from './frame';
import scope from './scope';
import slide from './slide';

export default { container, frame, scope, slide };
